import pandas as pd
a = pd.read_csv(r"/Users/nguyenxuanty/Documents/Baitappython/baitapchuong5/region.csv")
print(a)